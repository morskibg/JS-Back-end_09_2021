module.exports = {
  TOKEN_SECRET:
    'arf@kBt4tns%VY*AU_m7*URHDhQxGtGMMk5?guzm_-D=g3yQ**WxFBgH4FjKTMg-kHTBurtvRcA6N',
  COOKIE_NAME: 'SESSION_DATA',
};
